# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_game:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/DenisDolgov1991/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DenisDolgov1991/python-project-49/actions)\n\n\nBRAIN-EVEN\nhttps://asciinema.org/a/yjmy7uC4t37rsI9FiQsFxOaCd\n\nBRAIN-CALC\nhttps://asciinema.org/a/3kD0TQG7V6KrFst7KNYaofnEW\n\nBRAINE-GCD\nhttps://asciinema.org/a/65llIemfyIaTodPi88Z7JZs6b\n\nBRAINE-PROGRESSION\nhttps://asciinema.org/a/NJyh2DxPR0zgykgcgMkrmK4Xe\n\nBRAINE-PRIME\nhttps://asciinema.org/a/XjNahMa5MKCFXrOB3kJ4yczKb\n',
    'author': 'DenisDolgov1991',
    'author_email': 'dolgovdenis1991@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
