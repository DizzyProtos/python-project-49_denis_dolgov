### Hexlet tests and linter status:
[![Actions Status](https://github.com/DenisDolgov1991/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DenisDolgov1991/python-project-49/actions)


BRAIN-EVEN
https://asciinema.org/a/yjmy7uC4t37rsI9FiQsFxOaCd

BRAIN-CALC
https://asciinema.org/a/3kD0TQG7V6KrFst7KNYaofnEW

BRAINE-GCD
https://asciinema.org/a/65llIemfyIaTodPi88Z7JZs6b

BRAINE-PROGRESSION
https://asciinema.org/a/NJyh2DxPR0zgykgcgMkrmK4Xe

BRAINE-PRIME
https://asciinema.org/a/XjNahMa5MKCFXrOB3kJ4yczKb
