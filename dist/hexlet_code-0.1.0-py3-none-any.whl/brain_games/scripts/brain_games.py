#!/brain_games/scripts.brain_games
def main():
    print('Welcome to the Brain Games!')

if __name__ == '__main__':
    main()

