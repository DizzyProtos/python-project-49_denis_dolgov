#!/usr/bin/env pyrhon3


from random import randint
import prompt
import math


GAME = 'Find the greatwst common divisor of given numbers'

def brain_ring():

    for _ in range(3):
        num1 = randint(1, 50)
        num2 = randint(1, 50)
        question = f'{num2} and {num2}'
        correct_answer = math.gcd(num1, num2)
        retutn question, correct_answer
